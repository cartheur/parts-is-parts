*PADS-LIBRARY-PART-TYPES-V9*

D0808-42 DIPS762W64P254L1000H451Q8N I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.15.17.24
"Mouser Part Number" 855-D0808-42
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/D0808-42?qs=ecHgFjcWJS%2F%2FYVKF%2FgPf%2FA%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" D0808-42
"Description" IC Socket: 4+4 Pos Receptacle DIL Straight Wire Wrap
"Datasheet Link" https://content.harwin.com/m/c4b27f4df74f6b3f/original/DRG-00108-Technical-Drawing-Datasheet-D0XXX-pdf.pdf
"Geometry.Height" 4.51mm
GATE 1 8 0
D0808-42
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
8 0 U 8
7 0 U 7
6 0 U 6
5 0 U 5

*END*
*REMARK* SamacSys ECAD Model
641368/1245687/2.50/8/2/Connector
