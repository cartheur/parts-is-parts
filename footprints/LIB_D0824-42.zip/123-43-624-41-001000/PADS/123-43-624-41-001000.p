*PADS-LIBRARY-PART-TYPES-V9*

123-43-624-41-001000 DIPS1524W64P254L3040H490Q24N I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.15.18.29
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Mill-Max
"Manufacturer_Part_Number" 123-43-624-41-001000
"Description" 24 (2 x 12) Pos DIP, 0.6" (15.24mm) Row Spacing Socket Gold Through Hole
"Datasheet Link" 
"Geometry.Height" 4.9mm
GATE 1 24 0
123-43-624-41-001000
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
24 0 U 24
23 0 U 23
22 0 U 22
21 0 U 21
20 0 U 20
19 0 U 19
18 0 U 18
17 0 U 17
16 0 U 16
15 0 U 15
14 0 U 14
13 0 U 13

*END*
*REMARK* SamacSys ECAD Model
15101798/1245687/2.50/24/3/Connector
