*PADS-LIBRARY-PART-TYPES-V9*

123-43-628-41-001000 1234362841001000 I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.16.22.54
"Mouser Part Number" 575-12343628
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Mill-Max/123-43-628-41-001000/?qs=IGgAdOvCTsSqORqiKCtp8w%3D%3D
"Manufacturer_Name" Mill-Max
"Manufacturer_Part_Number" 123-43-628-41-001000
"Description" 28 (2 x 14) Pos DIP, 0.6" (15.24mm) Row Spacing Socket Gold Through Hole, 3A , -55C ~ 125C
"Datasheet Link" https://www.mill-max.com/catalog/download/2017-11:109.pdf
"Geometry.Height" 4.9022mm
GATE 1 28 0
123-43-628-41-001000
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20
21 0 U 21
22 0 U 22
23 0 U 23
24 0 U 24
25 0 U 25
26 0 U 26
27 0 U 27
28 0 U 28

*END*
*REMARK* SamacSys ECAD Model
571100/1245687/2.50/28/3/Connector
