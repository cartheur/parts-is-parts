*PADS-LIBRARY-PART-TYPES-V9*

D0820-42 D082042 I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.16.20.36
"Mouser Part Number" 855-D0820-42
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/D0820-42?qs=ecHgFjcWJS8oZI6MZS%252BciQ%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" D0820-42
"Description" IC Socket: 10+10 Pos Receptacle DIL Straight Wire Wrap
"Datasheet Link" https://content.harwin.com/m/c4b27f4df74f6b3f/original/DRG-00108-Technical-Drawing-Datasheet-D0XXX-pdf.pdf
"Geometry.Height" 4.51mm
GATE 1 20 0
D0820-42
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20

*END*
*REMARK* SamacSys ECAD Model
288224/1245687/2.50/20/2/Connector
