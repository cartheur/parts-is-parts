*PADS-LIBRARY-PART-TYPES-V9*

D0814-42 D081442 I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.16.17.54
"Mouser Part Number" 855-D0814-42
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/D0814-42?qs=ecHgFjcWJS%252BYcLqPXtw6BA%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" D0814-42
"Description" IC Socket: 7+7 Pos Receptacle DIL Straight Wire Wrap
"Datasheet Link" https://content.harwin.com/m/c4b27f4df74f6b3f/original/DRG-00108-Technical-Drawing-Datasheet-D0XXX-pdf.pdf
"Geometry.Height" 4.51mm
GATE 1 14 0
D0814-42
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14

*END*
*REMARK* SamacSys ECAD Model
233934/1245687/2.50/14/2/Connector
