*PADS-LIBRARY-PART-TYPES-V9*

D0816-42 DIPS762W64P254L2020H451Q16N I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.15.17.42
"Mouser Part Number" 855-D0816-42
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/D0816-42?qs=ecHgFjcWJS%252Brp0Xb4F2tcA%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" D0816-42
"Description" IC Socket: 8+8 Pos Receptacle DIL Straight Wire Wrap
"Datasheet Link" https://content.harwin.com/m/c4b27f4df74f6b3f/original/DRG-00108-Technical-Drawing-Datasheet-D0XXX-pdf.pdf
"Geometry.Height" 4.51mm
GATE 1 16 0
D0816-42
1 0 U 1
2 0 U 2
3 0 U 3
4 0 G 4
5 0 U 5
6 0 U 6
7 0 G 7
8 0 U 8
16 0 G 16
15 0 U 15
14 0 U 14
13 0 G 13
12 0 U 12
11 0 U 11
10 0 U 10
9 0 U 9

*END*
*REMARK* SamacSys ECAD Model
570712/1245687/2.50/16/2/Connector
