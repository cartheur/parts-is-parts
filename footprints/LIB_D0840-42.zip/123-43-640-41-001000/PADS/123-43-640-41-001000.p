*PADS-LIBRARY-PART-TYPES-V9*

123-43-640-41-001000 DIPS1524W64P254L5080H490Q40N I CON 7 1 0 0 0
TIMESTAMP 2026.09.04.15.22.08
"Mouser Part Number" 575-12343640
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Mill-Max/123-43-640-41-001000?qs=IGgAdOvCTsT9sWDKLd%2FHYA%3D%3D
"Manufacturer_Name" Mill-Max
"Manufacturer_Part_Number" 123-43-640-41-001000
"Description" IC & Component Sockets 40P TIN PIN GLD CONT
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/123-43-640-41-001000.pdf
"Geometry.Height" 4.902mm
GATE 1 40 0
123-43-640-41-001000
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20
40 0 U 40
39 0 U 39
38 0 U 38
37 0 U 37
36 0 U 36
35 0 U 35
34 0 U 34
33 0 U 33
32 0 U 32
31 0 U 31
30 0 U 30
29 0 U 29
28 0 U 28
27 0 U 27
26 0 U 26
25 0 U 25
24 0 U 24
23 0 U 23
22 0 U 22
21 0 U 21

*END*
*REMARK* SamacSys ECAD Model
805640/1245687/2.50/40/3/Connector
